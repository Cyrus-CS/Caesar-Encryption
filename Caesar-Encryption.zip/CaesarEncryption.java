public class CaesarEncryption {
    public static void main(String[] args) {
        String result = toEncrypt("salut je ne suis qu'un simple test", 2);
        System.out.println(result);
    }

    static String toEncrypt(String text, int step) {
        //lettre majuscule 
        char[] uppercase = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        //lettre miniscule
        char[] lowercase = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        // déclaration de la variable de sortie, qui contiendra toute les lettres cryptées
        StringBuilder outText = new StringBuilder();

        //on parcourt notre texte (en comptant le nombre de caractère = grâce à length) qu'on passera en paramètre
        for (int i = 0; i < text.length(); i++) {
            char letter = text.charAt(i);
            if (Character.isUpperCase(letter)) {
                int index = new String(uppercase).indexOf(letter);
                int crypting = (index + step) % 26;
                char newLetter = uppercase[crypting];
                outText.append(newLetter);
            } else if (Character.isLowerCase(letter)) {
                int index = new String(lowercase).indexOf(letter);
                int crypting = (index + step) % 26;
                char newLetter = lowercase[crypting];
                outText.append(newLetter);
            } else {
                outText.append(letter);
            }
        }

        return outText.toString();
    }
}
